# PORTAL 2 — Android prank (Python + Kivy)

## Project files
- `main.py` — app source.
- `buildozer.spec` — Buildozer settings.
- `assets/portal_scene.jpg` — add your own dark Portal 2 image here.
- `assets/portal_sound.mp3` — add your own sound effect here.

No images or audio are bundled. If either asset is missing, the app still opens; the scare screen shows a text fallback and sound is simply skipped.

## Run on Android
For a quick Python-only test, use an Android Python IDE that supports Kivy. Not every Android Python IDE supports Kivy's full UI stack.

## Build an APK
Buildozer is normally run on Linux. Building a Kivy APK directly on Android/Termux is possible only with a more involved setup and can be fragile; the most reliable route is a Linux environment (for example Ubuntu in WSL2 on a computer, or a Linux machine).

Typical Linux commands:
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip setuptools wheel
pip install buildozer
buildozer -v android debug
```

The APK is normally placed in `bin/`.

## Notes
- The app requests no special Android permissions.
- Android's Back button returns to the menu from the scare screen.
- The screen switch is immediate (no transition animation). Actual audio/display latency depends on Android and the device.
- Use media you have permission to include if you share the APK.


## Cloud APK build (phone-friendly)

This project includes a GitHub Actions workflow at `.github/workflows/build.yml`.
Upload the project files to a GitHub repository, then open the repository's Actions tab
and run **Build Android APK** (or push a commit to the `main` branch). When the run
finishes successfully, download the `portal2-apk` artifact from that run.
