from pathlib import Path

from kivy.config import Config
Config.set("graphics", "orientation", "portrait")

from kivy.app import App
from kivy.core.audio import SoundLoader
from kivy.core.window import Window
from kivy.uix.screenmanager import ScreenManager, Screen, NoTransition
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.image import Image
from kivy.graphics import Color, Rectangle

BASE_DIR = Path(__file__).resolve().parent
IMAGE_PATH = BASE_DIR / "assets" / "portal_scene.jpg"
SOUND_PATH = BASE_DIR / "assets" / "portal_sound.mp3"


class MenuScreen(Screen):
    def __init__(self, on_play, **kwargs):
        super().__init__(**kwargs)
        with self.canvas.before:
            Color(0.055, 0.065, 0.075, 1)
            self.bg = Rectangle(pos=self.pos, size=self.size)
        self.bind(pos=self.update_bg, size=self.update_bg)

        layout = BoxLayout(
            orientation="vertical",
            padding=("32dp", "60dp"),
            spacing="24dp",
        )
        layout.add_widget(Label(
            text="[b]PORTAL 2[/b]",
            markup=True,
            font_size="38sp",
            color=(0.9, 0.92, 0.95, 1),
            size_hint_y=0.55,
        ))
        layout.add_widget(Label(
            text="APERTURE SCIENCE",
            font_size="13sp",
            color=(0.48, 0.53, 0.59, 1),
            size_hint_y=0.2,
        ))
        play_button = Button(
            text="ИГРАТЬ",
            font_size="20sp",
            bold=True,
            color=(0.08, 0.09, 0.1, 1),
            background_normal="",
            background_down="",
            background_color=(0.88, 0.9, 0.92, 1),
            size_hint=(1, 0.22),
        )
        play_button.bind(on_release=on_play)
        layout.add_widget(play_button)
        layout.add_widget(Label(size_hint_y=0.25))
        self.add_widget(layout)

    def update_bg(self, *_):
        self.bg.pos = self.pos
        self.bg.size = self.size


class ScareScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        with self.canvas.before:
            Color(0, 0, 0, 1)
            self.bg = Rectangle(pos=self.pos, size=self.size)
        self.bind(pos=self.update_bg, size=self.update_bg)

        if IMAGE_PATH.is_file():
            self.add_widget(Image(
                source=str(IMAGE_PATH),
                allow_stretch=True,
                keep_ratio=False,
            ))
        else:
            self.add_widget(Label(
                text="Добавь assets/portal_scene.jpg",
                color=(0.5, 0.5, 0.5, 1),
                font_size="14sp",
            ))

    def update_bg(self, *_):
        self.bg.pos = self.pos
        self.bg.size = self.size


class Portal2App(App):
    def build(self):
        Window.clearcolor = (0, 0, 0, 1)
        self.sound = None
        if SOUND_PATH.is_file():
            self.sound = SoundLoader.load(str(SOUND_PATH))

        self.manager = ScreenManager(transition=NoTransition())
        self.manager.add_widget(MenuScreen(name="menu", on_play=self.play))
        self.manager.add_widget(ScareScreen(name="scare"))
        Window.bind(on_keyboard=self.on_keyboard)
        return self.manager

    def play(self, *_):
        # Change screen first; audio is preloaded during app startup.
        self.manager.current = "scare"
        if self.sound:
            self.sound.stop()
            self.sound.play()

    def on_keyboard(self, _window, key, *_args):
        # Android Back key.
        if key == 27 and self.manager.current == "scare":
            if self.sound:
                self.sound.stop()
            self.manager.current = "menu"
            return True
        return False

    def on_pause(self):
        return True

    def on_stop(self):
        if self.sound:
            self.sound.stop()
            if hasattr(self.sound, "unload"):
                self.sound.unload()


if __name__ == "__main__":
    Portal2App().run()
