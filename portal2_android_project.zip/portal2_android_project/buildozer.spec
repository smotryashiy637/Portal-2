[app]

title = PORTAL 2
package.name = portal2prank
package.domain = org.aperturescience

source.dir = .
source.include_exts = py,kv,png,jpg,jpeg,ogg,mp3,wav,md
version = 0.1

requirements = python3,kivy
orientation = portrait
fullscreen = 1

# This app does not need network, storage, microphone, or other Android permissions.
android.permissions =
android.minapi = 23
android.api = 35

[buildozer]
log_level = 2
warn_on_root = 1
