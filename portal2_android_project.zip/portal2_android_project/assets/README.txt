Place your own media files in this folder:
- portal_scene.jpg (the image shown after pressing PLAY)
- portal_sound.mp3 (the sound played after pressing PLAY)

Keep these exact filenames, or update the paths in main.py.
